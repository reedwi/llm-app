import boto3
import json
import os
from .obo_langchain import get_answer
from .obo_slack import get_thread_history, reply_in_thread
from supabase import Client, create_client

sqs_client = boto3.client('sqs')
supabase: Client = create_client(os.getenv('SUPABASE_URL'), os.getenv('SUPABASE_KEY'))

def lambda_handler(event, context):
    # TODO implement
    messages = event['Records']
    for message in messages:
        message_body = json.loads(message['body'])

        slack_team_id = message_body['event']['slack_team_id']
        namespace = message_body['event']['chatbot']
        message_ts = message_body['event']['message_ts']
        question = message_body['event']['question']
        original_question = message_body['event']['original_question']
        channel_id = message_body['event']['channel_id']

        receipt_handle = message['receiptHandle']

        print(question)
        delete_message = sqs_client.delete_message(
            QueueUrl=os.getenv('SQS_URL'),
            ReceiptHandle=receipt_handle
        )

        supabase.postgrest.schema('public')

        item = supabase.table('accounts').select('*').eq('slack_team_id', slack_team_id).execute()
        try:
            account = item.data[0]
            print(f'account: {account}')
        except:
            account = None
            print('Could not return account from supabase')

        if not account:
            return {
                'statusCode': 200,
                'body': json.dumps('There is an error finding your account')
            }

        if original_question:
            chat_history = None
        else:
            chat_history = get_thread_history(slack_key=account['token'], channel_id=channel_id, thread_ts=message_ts)

        answer_obj = get_answer(namespace=namespace, question=question, chat_history=chat_history)
        if answer_obj['chatgpt']:
            reply = reply_in_thread(slack_key=account['token'], channel_id=channel_id, thread_ts=message_ts, text=answer_obj['answer'])
        else:
            # TODO: Go through source documents
            answer_obj['answer'] += '\n\n*Source(s)*'
            for i, document in enumerate(answer_obj['response']['source_documents'], start=1):
                supabase.postgrest.schema('storage')
                item = supabase.table('objects').select('*').eq('id', document.metadata['doc_id']).execute()
                try:
                    doc_obj = item.data[0]
                except:
                    doc_obj = None
                    print('Could not return document object from supabase')
                if not doc_obj:
                    continue
                try:
                    document_res = supabase.storage.get_bucket(doc_obj['bucket_id']).create_signed_url(path=doc_obj['name'], expires_in=3600)
                    source_url = document_res['signedURL']
                    answer_obj['answer'] += f'\n<{source_url}|{doc_obj["path_tokens"][-1]}>'
                except:
                    pass
                # print(document_res)
            reply = reply_in_thread(slack_key=account['token'], channel_id=channel_id, thread_ts=message_ts, text=answer_obj['answer'])

        
        usage_obj = {
            'tokens_used': answer_obj['tokens_used'],
            'prompt': question,
            'answer': answer_obj['answer'],
            'account_id': account['id'],
            'index_namespace': namespace
        }
        supabase.postgrest.schema('public')
        supabase.table('usage').insert(usage_obj).execute()
        
    return {
        'statusCode': 200,
        'body': json.dumps('Hello from Lambda!')
    }